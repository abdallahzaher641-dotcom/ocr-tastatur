package com.example.ocrkeyboard

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        layout.addView(TextView(this).apply {
            text = "OCR Tastatur\n\n1. Foto-Zugriff erlauben\n2. Tastatur aktivieren\n" +
                "3. In einem Textfeld die Tastatur wechseln und \"Letztes Foto scannen\" tippen."
            textSize = 16f
        })

        layout.addView(Button(this).apply {
            text = "Foto-Zugriff erlauben"
            setOnClickListener {
                val perm = if (Build.VERSION.SDK_INT >= 33)
                    Manifest.permission.READ_MEDIA_IMAGES
                else
                    Manifest.permission.READ_EXTERNAL_STORAGE
                permissionLauncher.launch(perm)
            }
        })

        layout.addView(Button(this).apply {
            text = "Tastatur aktivieren"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        })

        setContentView(layout)
    }
}
