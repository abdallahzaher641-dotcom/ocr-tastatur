package com.example.ocrkeyboard

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class OcrKeyboardService : InputMethodService() {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }
    private var status: TextView? = null

    override fun onCreateInputView(): View {
        val view = LayoutInflater.from(this).inflate(R.layout.keyboard_view, null)
        status = view.findViewById(R.id.status)

        view.findViewById<Button>(R.id.btnScan).setOnClickListener { scanLatestPhoto() }
        view.findViewById<Button>(R.id.btnSpace).setOnClickListener {
            currentInputConnection?.commitText(" ", 1)
        }
        view.findViewById<Button>(R.id.btnDelete).setOnClickListener {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }
        view.findViewById<Button>(R.id.btnSwitch).setOnClickListener {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showInputMethodPicker()
        }
        return view
    }

    private fun hasPhotoPermission(): Boolean {
        val perm = if (Build.VERSION.SDK_INT >= 33)
            Manifest.permission.READ_MEDIA_IMAGES
        else
            Manifest.permission.READ_EXTERNAL_STORAGE
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
    }

    private fun latestPhotoUri(): Uri? {
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        contentResolver.query(
            collection,
            arrayOf(MediaStore.Images.Media._ID),
            null, null,
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { c ->
            if (c.moveToFirst()) {
                return ContentUris.withAppendedId(collection, c.getLong(0))
            }
        }
        return null
    }

    private fun scanLatestPhoto() {
        if (!hasPhotoPermission()) {
            status?.text = "Kein Foto-Zugriff. Bitte in der App erlauben."
            return
        }
        val uri = latestPhotoUri()
        if (uri == null) {
            status?.text = "Kein Foto gefunden."
            return
        }
        status?.text = "Erkenne Text …"
        try {
            val image = InputImage.fromFilePath(this, uri)
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    val text = result.text.trim()
                    if (text.isEmpty()) {
                        status?.text = "Kein Text erkannt."
                    } else {
                        currentInputConnection?.commitText(text, 1)
                        status?.text = "Text eingefügt."
                    }
                }
                .addOnFailureListener {
                    status?.text = "Fehler bei der Texterkennung."
                }
        } catch (e: Exception) {
            status?.text = "Bild konnte nicht gelesen werden."
        }
    }

    override fun onDestroy() {
        recognizer.close()
        super.onDestroy()
    }
}
