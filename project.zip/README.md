# OCR Tastatur
Android-Tastatur, die Text aus dem letzten Foto erkennt und ins Textfeld einfügt.
